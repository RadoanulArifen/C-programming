#include<stdio.h>
int main()
{
    printf("1.Biriyani\n2.Burger\n3.Pizza");
    return 0;
}
