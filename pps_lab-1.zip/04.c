#include<stdio.h>
int main()
{
    int x1,x2,x3,sum;

    scanf("%d %d %d",&x1,&x2,&x3);
    sum=x1+x2+x3;
     printf("%d + %d +%d=%d",x1,x2,x3,sum);
    return 0;
}
