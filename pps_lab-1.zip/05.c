#include<stdio.h>
int main()
{
    float a,b,sum;
    scanf("%f %f",&a,&b);
    sum=(((a+b)/2)*3);
    printf("sum=%.5f\n",sum);
    return 0;
}

