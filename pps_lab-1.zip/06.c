#include<stdio.h>
int main()
{
    float a,b,c,d,sum;
    scanf("%f %f %f %f",&a,&b,&c,&d,sum);
    sum=(((a+b+c+d)/2)-1);
    printf("sum=%.2f\n",sum);
    return 0;
}
