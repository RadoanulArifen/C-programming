#include<stdio.h>
int main()
{
int a,b,sum;
scanf("%d %d",&a,&b);
sum=a+b;
if(sum>5)
    printf("Well done");
else
    printf("Try again later");
return 0;
}
