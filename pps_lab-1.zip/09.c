#include<stdio.h>
int main()
{
    char name;
    int id;

    printf("What is your name?\n");
    scanf("%s", &name);

    printf("What is your ID?\n");
    scanf("%d", &id);


    printf("Thank you.\n");

    return 0;
}
