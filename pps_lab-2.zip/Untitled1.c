#include<stdio.h>
int main()
{
    printf("Radoanul Arifen\n");

    return 0;
}
