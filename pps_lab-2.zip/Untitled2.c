#include<stdio.h>
int main()
{
    printf("Radoanul Arifen \t 221-15-5284\n");

    return 0;
}

