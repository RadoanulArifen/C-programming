#include<stdio.h>
int main()
{
    float a=7.11 , b=8,sum;

    sum=a+b;

    printf("%.2f\n",sum);


    return 0;
}

