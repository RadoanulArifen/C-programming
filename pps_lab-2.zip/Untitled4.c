#include<stdio.h>
int main()
{
    int a=6 , b=2, c=8, d=4,sum;

    sum=a+b+c+d;

    printf("%d+%d+%d+%d=%d\n",a,b,c,d,sum);


    return 0;
}


