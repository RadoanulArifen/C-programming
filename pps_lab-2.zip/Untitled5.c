#include<stdio.h>
int main()
{
int a=3,b=2,c=6,d=4,e=5,f=1,sum1,sum2,sum3,sum4;

sum1=a+b;
sum2=c+d;
sum3=e+f;
sum4=sum1+sum2+sum3;

printf("%d+%d=%d\n%d+%d=%d\n%d+%d=%d\n%d+%d+%d=%d\n",a,b,sum1,c,d,sum2,e,f,sum3,sum1,sum2,sum3,sum4);


    return 0;
}


